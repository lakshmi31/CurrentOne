package com.card.customconverters;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.dozer.DozerConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateToStringConverter extends DozerConverter<Date, String> {

	private static final Logger LOG = LoggerFactory.getLogger(DateToStringConverter.class);

	public DateToStringConverter() {
		super(Date.class, String.class);
	}

	@Override
	public String convertTo(Date source, String destination) {
		LOG.info("Inside converter");
		if (source == null) {
			return null;
		}
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		destination = df.format(source);
		return destination;
	}

	@Override
	public Date convertFrom(String arg0, Date arg1) {
		return null;
	}

}
