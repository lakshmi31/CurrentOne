package com.card.dozer;

/**
 * 
 * @author ldudhbha
 *
 */
//@Configuration
public class DozerConfig {

  /*  @Bean(name = "org.dozer.Mapper")
    public DozerBeanMapper dozerBean() {
        List<String> mappingFiles = Arrays.asList(
                Constants.DOZER_MAPPING_FILE
        );

        DozerBeanMapper dozerBean = new DozerBeanMapper();
        dozerBean.setMappingFiles(mappingFiles);
        return dozerBean;
    }
*/
}