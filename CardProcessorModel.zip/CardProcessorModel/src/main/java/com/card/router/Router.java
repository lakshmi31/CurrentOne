package com.card.router;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.properties.PropertiesComponent;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.spring.SpringCamelContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.card.common.ReadSourceDestinationXML;
import com.card.constant.Constants;
import com.card.processor.MyConsumerProcessor;
import com.card.source.model.Customer;

/**
 * Consumer router to route message from ProcessorModel to Simulator
 *
 */
@Component
public class Router extends RouteBuilder {
	private static final Logger LOG = LoggerFactory.getLogger(Router.class);
	ReadSourceDestinationXML readSourceDestinationXML = new ReadSourceDestinationXML();

	/*@Autowired
	SpringCamelContext context;*/
	
	@Override
	public void configure() throws Exception {
		//SourceDestination sourceDestination = readSourceDestinationXML.readXML();
		//LOG.info("protocol is:" + sourceDestination.getProtocol());
		PropertiesComponent pc = new PropertiesComponent();
		pc.setLocation("classpath:application.properties");
		getContext().addComponent("properties", pc);
		/*PropertiesComponent pc = getContext().getComponent("properties", PropertiesComponent.class);
		pc.setCache(false);*/
		
		
		
		 from(Constants.TIMER).to(Constants.SOURCE_URL_TO_CONSUME).unmarshal().json(JsonLibrary.Jackson, Customer.class)
				.process(new MyConsumerProcessor()).log(Constants.DESTINATION_URL_JMS)
				/*.setHeader(sourceDestination.getProtocol(), constant(sourceDestination.getProtocol())).choice()
				.when(header(sourceDestination.getProtocol()).isEqualTo(Constants.DESTINATION_NAME_JMS))*/
				.to(Constants.DESTINATION_URL_JMS);
			//	.when(header(sourceDestination.getProtocol()).isEqualTo(Constants.DESTINATION_NAME_TCP))
				/*.to(Constants.DESTINATION_URL_TCP).end()).from(Constants.TIMER).to(Constants.DESTINATION_URL_TO_PRODUCE).marshal().json(JsonLibrary.Jackson, CustomerResponseDest.class)
				.log("Marshalled data:${body}").process(new MyProducerProcessor()).log("Response body:${body}")
				.to(Constants.SOURCE_URL_TO_PRODUCE);*/
	}

}
